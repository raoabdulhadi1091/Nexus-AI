import { Conversation, ReplyMode, AttachedFile, ChatMessage, VoiceNoteAttachment } from '../types';

const STORAGE_KEY_CONVS = 'nexus_ai_conversations';
const STORAGE_KEY_PINNED = 'nexus_ai_pinned';

export interface SendChatOptions {
  history?: ChatMessage[];
  voiceNote?: VoiceNoteAttachment;
  secondaryFile?: AttachedFile;
  forceImageGen?: boolean;
  referenceImage?: {
    base64: string;
    mimeType?: string;
  };
}

export interface ChatResponsePayload {
  reply: string;
  status: 'ok' | 'error';
  generated_image_b64?: string;
  generated_image_mime?: string;
  generated_prompt?: string;
  client_studio_enhance?: boolean;
  transcript?: string;
}

/**
 * Browser-side Studio Ultra-HD Image Enhancer (2x Bicubic Super-Sampling + Luminance Unsharp Masking + Studio Dynamic Range).
 * Preserves 100% of the user's exact face, identity, and photo when they ask "iski quality improve kro" / "improve quality".
 */
async function enhanceImageStudioHD(
  base64: string,
  mimeType = 'image/png'
): Promise<{ b64: string; mime: string }> {
  if (typeof document === 'undefined' || typeof Image === 'undefined') {
    return { b64: base64, mime: mimeType };
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const srcW = img.naturalWidth || img.width || 512;
        const srcH = img.naturalHeight || img.height || 512;
        // Upscale up to 2x (capped at 1920px on longest side for fast, crisp Ultra-HD rendering)
        const maxSide = Math.max(srcW, srcH);
        const scale = maxSide < 960 ? 2.0 : maxSide < 1440 ? 1.5 : 1.15;
        const dstW = Math.round(srcW * scale);
        const dstH = Math.round(srcH * scale);

        const canvas = document.createElement('canvas');
        canvas.width = dstW;
        canvas.height = dstH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({ b64: base64, mime: mimeType });
          return;
        }

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        // Apply subtle studio clarity, contrast, and natural saturation boost during high-res resample
        ctx.filter = 'contrast(1.08) saturate(1.09) brightness(1.03)';
        ctx.drawImage(img, 0, 0, dstW, dstH);
        ctx.filter = 'none';

        // Apply Luminance Unsharp Mask (USM) 3x3 sharpening kernel to bring out fine facial, eye, hair, and texture details
        const imgData = ctx.getImageData(0, 0, dstW, dstH);
        const src = imgData.data;
        const out = new Uint8ClampedArray(src);
        const amount = 0.42; // Studio-grade sharpening strength without halo artifacts

        for (let y = 1; y < dstH - 1; y++) {
          const rowOffset = y * dstW * 4;
          const prevRow = (y - 1) * dstW * 4;
          const nextRow = (y + 1) * dstW * 4;
          for (let x = 1; x < dstW - 1; x++) {
            const idx = rowOffset + x * 4;
            for (let c = 0; c < 3; c++) {
              const center = src[idx + c];
              const neighbors =
                (src[prevRow + x * 4 + c] +
                  src[nextRow + x * 4 + c] +
                  src[rowOffset + (x - 1) * 4 + c] +
                  src[rowOffset + (x + 1) * 4 + c]) *
                0.25;
              const diff = center - neighbors;
              // Threshold tiny noise while sharpening real edges and textures
              if (Math.abs(diff) > 2) {
                const val = center + diff * amount * 2.2;
                out[idx + c] = val < 0 ? 0 : val > 255 ? 255 : val;
              }
            }
          }
        }

        imgData.data.set(out);
        ctx.putImageData(imgData, 0, 0);

        const dataUrl = canvas.toDataURL('image/png', 1.0);
        const commaIdx = dataUrl.indexOf(',');
        const enhancedB64 = commaIdx !== -1 ? dataUrl.slice(commaIdx + 1) : dataUrl;
        resolve({ b64: enhancedB64 || base64, mime: 'image/png' });
      } catch {
        resolve({ b64: base64, mime: mimeType });
      }
    };
    img.onerror = () => resolve({ b64: base64, mime: mimeType });
    img.src = base64.startsWith('data:') ? base64 : `data:${mimeType};base64,${base64}`;
  });
}

export async function sendChatMessage(
  message: string,
  sessionId: string,
  mode: ReplyMode,
  file?: AttachedFile,
  signal?: AbortSignal,
  options?: SendChatOptions
): Promise<ChatResponsePayload> {
  try {
    // Prepare lightweight history for context (last 10 turns)
    const compactHistory = (options?.history || []).slice(-10).map((m) => ({
      role: m.role,
      content: m.content,
      image_b64: m.image_b64,
      image_mime_type: m.image_mime_type,
      generated_image_b64: m.generated_image_b64,
      generated_image_mime: m.generated_image_mime,
      generated_prompt: m.generated_prompt,
    }));

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        session_id: sessionId,
        mode,
        file: file
          ? {
              name: file.name,
              size: file.size,
              type: file.type,
              mimeType: file.mimeType || file.type,
              content: file.content,
              base64: file.base64 || (file.isImage || file.isAudio ? file.content : undefined),
              isImage: file.isImage,
              isAudio: file.isAudio,
            }
          : undefined,
        secondaryFile: options?.secondaryFile
          ? {
              name: options.secondaryFile.name,
              size: options.secondaryFile.size,
              type: options.secondaryFile.type,
              mimeType: options.secondaryFile.mimeType || options.secondaryFile.type,
              content: options.secondaryFile.content,
              base64:
                options.secondaryFile.base64 ||
                (options.secondaryFile.isImage || options.secondaryFile.isAudio
                  ? options.secondaryFile.content
                  : undefined),
              isImage: options.secondaryFile.isImage,
              isAudio: options.secondaryFile.isAudio,
            }
          : undefined,
        voiceNote: options?.voiceNote
          ? {
              name: options.voiceNote.name,
              size: options.voiceNote.size,
              mimeType: options.voiceNote.mimeType,
              base64: options.voiceNote.base64,
              transcript: options.voiceNote.transcript,
              clientTranscriptHint: options.voiceNote.clientTranscriptHint,
            }
          : undefined,
        history: compactHistory,
        forceImageGen: options?.forceImageGen,
        referenceImage: options?.referenceImage,
      }),
      signal,
    });

    if (!res.ok) {
      const errorJson = await res.json().catch(() => null);
      if (errorJson && errorJson.reply) {
        return { reply: errorJson.reply, status: 'error' };
      }
      return {
        reply: '⚠️ NEXUS AI encountered an error processing your request. Please try again.',
        status: 'error',
      };
    }

    const data: ChatResponsePayload = await res.json();

    // If the user requested quality improvement of their own photo and client_studio_enhance is flagged,
    // run Studio Ultra-HD 2x Super-Sampling + Unsharp Masking on the exact photo
    if (data?.client_studio_enhance && data?.generated_image_b64) {
      const enhanced = await enhanceImageStudioHD(
        data.generated_image_b64,
        data.generated_image_mime || 'image/png'
      );
      data.generated_image_b64 = enhanced.b64;
      data.generated_image_mime = enhanced.mime;
    }

    return data;
  } catch (err: any) {
    if (err.name === 'AbortError') {
      return { reply: '⏹️ *Response generation stopped.*', status: 'ok' };
    }
    return {
      reply: '⚠️ Network error: Could not reach NEXUS AI backend. Please try again.',
      status: 'error',
    };
  }
}

export async function transcribeVoiceNote(
  audioBase64: string,
  mimeType: string,
  mode?: ReplyMode,
  signal?: AbortSignal,
  clientTranscriptHint?: string
): Promise<{ transcript?: string; error?: string; status: 'ok' | 'error' }> {
  try {
    const res = await fetch('/api/transcribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        audioBase64,
        mimeType,
        mode,
        clientTranscriptHint,
      }),
      signal,
    });

    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.status === 'error' || !data.transcript) {
      if (clientTranscriptHint && clientTranscriptHint.trim()) {
        return { transcript: clientTranscriptHint.trim(), status: 'ok' };
      }
      return {
        error: data?.error || "I couldn't understand that voice message. Please try again.",
        status: 'error',
      };
    }
    return { transcript: data.transcript, status: 'ok' };
  } catch (err: any) {
    if (err.name === 'AbortError') {
      return { error: 'Transcription stopped.', status: 'error' };
    }
    if (clientTranscriptHint && clientTranscriptHint.trim()) {
      return { transcript: clientTranscriptHint.trim(), status: 'ok' };
    }
    return {
      error: "I couldn't understand that voice message. Please try again.",
      status: 'error',
    };
  }
}

export async function synthesizeSpeech(
  text: string,
  signal?: AbortSignal
): Promise<{ audioBase64?: string; mimeType?: string; status: 'ok' | 'error' }> {
  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
      signal,
    });
    if (!res.ok) {
      return { status: 'error' };
    }
    return await res.json();
  } catch {
    return { status: 'error' };
  }
}

export async function fetchConversations(): Promise<Conversation[]> {
  try {
    const res = await fetch('/api/conversations');
    if (res.ok) {
      const list = await res.json();
      try {
        localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(list));
      } catch {}
      return list;
    }
  } catch {
    // Offline or server not ready, fallback to local storage
  }

  const cached = localStorage.getItem(STORAGE_KEY_CONVS);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      return [];
    }
  }
  return [];
}

export async function saveConversation(conv: Conversation): Promise<boolean> {
  // Update local storage first (with safe fallback if base64 images exceed browser localStorage quota)
  try {
    const cached = localStorage.getItem(STORAGE_KEY_CONVS);
    const list: Conversation[] = cached ? JSON.parse(cached) : [];
    const index = list.findIndex((c) => c.id === conv.id);
    if (index >= 0) {
      list[index] = conv;
    } else {
      list.unshift(conv);
    }
    try {
      localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(list));
    } catch {
      // Trim heavy audio blobs if quota exceeded in localStorage
      const lightList = list.map((c) => ({
        ...c,
        messages: c.messages.map((m) => ({
          ...m,
          audio_b64: undefined,
        })),
      }));
      localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(lightList));
    }
  } catch (err) {
    console.error('Local save error:', err);
  }

  // Update server
  try {
    const res = await fetch('/api/conversations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(conv),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function deleteConversation(id: string): Promise<boolean> {
  try {
    const cached = localStorage.getItem(STORAGE_KEY_CONVS);
    if (cached) {
      const list: Conversation[] = JSON.parse(cached);
      const filtered = list.filter((c) => c.id !== id);
      localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(filtered));
    }
  } catch {}

  try {
    const res = await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
    return res.ok;
  } catch {
    return true;
  }
}

export async function deleteAllConversations(): Promise<boolean> {
  localStorage.removeItem(STORAGE_KEY_CONVS);
  localStorage.removeItem(STORAGE_KEY_PINNED);

  try {
    const res = await fetch('/api/conversations', { method: 'DELETE' });
    return res.ok;
  } catch {
    return true;
  }
}

export async function fetchPinned(): Promise<string[]> {
  try {
    const res = await fetch('/api/pinned');
    if (res.ok) {
      const ids = await res.json();
      localStorage.setItem(STORAGE_KEY_PINNED, JSON.stringify(ids));
      return ids;
    }
  } catch {}

  const cached = localStorage.getItem(STORAGE_KEY_PINNED);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      return [];
    }
  }
  return [];
}

export async function savePinned(ids: string[]): Promise<boolean> {
  localStorage.setItem(STORAGE_KEY_PINNED, JSON.stringify(ids));
  try {
    const res = await fetch('/api/pinned', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });
    return res.ok;
  } catch {
    return true;
  }
}

export async function checkServerStatus(): Promise<{
  app: string;
  status: string;
  webhookUrl: string;
  webhookStatus: string;
  modes: string[];
} | null> {
  try {
    const res = await fetch('/api/status');
    if (res.ok) {
      return await res.json();
    }
  } catch {}
  return null;
}

export function exportChatToMarkdown(conversation: Conversation) {
  const lines = [
    `# ${conversation.title}`,
    `*Exported from NEXUS AI on ${new Date().toLocaleString()}*`,
    `*Session ID: ${conversation.id}*`,
    '',
    '---',
    '',
  ];

  for (const msg of conversation.messages) {
    const who = msg.role === 'user' ? '👤 **You**' : '✦ **NEXUS AI**';
    const time = msg.ts ? ` *(${new Date(msg.ts * 1000).toLocaleTimeString()})*` : '';
    lines.push(`${who}${time}:`);
    lines.push('');
    if (msg.file_info) {
      lines.push(`> 📎 **Attached:** ${msg.file_info}`);
      lines.push('');
    }
    lines.push(msg.content);
    lines.push('');
    lines.push('---');
    lines.push('');
  }

  const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const safeTitle = (conversation.title || 'nexus-chat').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
  a.download = `${safeTitle}.md`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
