---
name: Imported source dependency checks
description: How to validate a standalone app archive inside this pnpm monorepo without changing root dependencies.
---

For standalone source archives kept outside the pnpm workspace, the package-install callback may try to add dependencies to the monorepo root and be blocked by pnpm's root-add guard. The bundled Bun 1.3.6 also cannot parse this app's Bun lockfile v2.

**Why:** Root dependency changes are unrelated to the imported app, and the Bun runtime version in this environment is older than the archive's lockfile format.

**How to apply:** Install and validate from the source directory with pnpm in isolated/no-lockfile mode, then remove generated `node_modules` and build output before finishing. Don't edit the monorepo root package files for this.
